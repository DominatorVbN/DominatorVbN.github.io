//
//  Persistence.swift
//  AmitSamantMachineTest
//
//  Created by Apple on 05/02/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation

class Persistence{
    static var userDef: UserDefaults{
        get{
            return UserDefaults.standard
        }
    }
    
    static var emailId: String?{
        get{
            return userDef.value(forKey: "emailId") as? String
        }
        set{
            userDef.set(newValue, forKey: "emailId")
            userDef.synchronize()
        }
    }
    
    static var isLoggedIn: Bool{
        get{
            return emailId != nil
        }
        set{
            if !newValue { emailId = nil }
        }
    }
}
