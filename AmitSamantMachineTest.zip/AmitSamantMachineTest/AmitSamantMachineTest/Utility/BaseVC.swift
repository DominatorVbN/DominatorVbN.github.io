//
//  BaseVC.swift
//  AmitSamantMachineTest
//
//  Created by Apple on 05/02/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import UIKit

class BaseVC: UIViewController {
    func showError (error: String){
        let alert = UIAlertController(title: "Error", message: error, preferredStyle: .alert)
        let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
        alert.addAction(ok)
        self.present(alert, animated: true, completion: nil)
    }
    //copied from stackoverflow
    func validateEmail(enteredEmail:String) -> Bool {
        
        let emailFormat = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPredicate = NSPredicate(format:"SELF MATCHES %@", emailFormat)
        return emailPredicate.evaluate(with: enteredEmail)
        
    }
    
    func doAction(user: User?, login: Bool){
        guard let context = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.viewContext else {
            showError(error: "Something went wrong!")
            return
        }
        do {
            let log = Log(context: context)
            log.time = Date() as NSDate
            log.user = user
            log.action = login
            try context.save()
        }catch{
            showError(error: "Error while saving log")
        }
    }
}
