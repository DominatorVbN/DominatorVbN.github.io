//
//  LogsTableVC.swift
//  AmitSamantMachineTest
//
//  Created by Apple on 05/02/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import UIKit
import CoreData

class LogsTableVC: UITableViewController {
    
    var logs: [Log]?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        guard let context = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.viewContext else {
            showError(error: "Something went wrong!")
            return
        }
        
        let request: NSFetchRequest<Log> = Log.fetchRequest()
        do {
            let result = try context.fetch(request)
            self.logs = result
            self.tableView.reloadData()
        }catch{
            showError(error: "Error while loading data")
        }
        
        
    }
    
    func showError (error: String){
        let alert = UIAlertController(title: "Error", message: error, preferredStyle: .alert)
        let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
        alert.addAction(ok)
        self.present(alert, animated: true, completion: nil)
    }

    // MARK: - Table view data source
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return logs == nil ? 0 : logs!.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .subtitle, reuseIdentifier: nil)
        
        let log = logs![indexPath.row]
        cell.textLabel?.text = log.user?.name
        let text: String
        if log.action == true{
            text = "Logged In"
        }else{
            text = "Logged Out"
        }
        
        cell.detailTextLabel?.text = "\(text) on \(log.time!)"

        // Configure the cell...

        return cell
    }

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
