//
//  ProfileVC.swift
//  AmitSamantMachineTest
//
//  Created by Apple on 05/02/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import UIKit
import CoreData

class ProfileVC: BaseVC {

    @IBOutlet weak var profileImageView: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var emailLabel: UILabel!
    @IBOutlet weak var phoneLabel: UILabel!
    var user: User?
    override func viewDidLoad() {
        super.viewDidLoad()
        guard let email = Persistence.emailId else {
            self.navigationController?.popViewController(animated: true)
            return
        }
        loadUser(email: email)
    }
    
    func loadUser(email: String){
        guard let context = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.viewContext else {
            showError(error: "Something went wrong!")
            return
        }
        
        let request: NSFetchRequest<User> = User.fetchRequest()
        do {
            let result = try context.fetch(request)
            guard let user = result.first(where: {$0.email == email}) else{
                showError(error: "No record found")
                return
            }
            self.user = user
            self.nameLabel.text = user.name
            self.emailLabel.text = user.email
            self.phoneLabel.text = user.phone
            if let data = user.profileImage as Data?{
                self.profileImageView.image = UIImage(data: data)
            }
        }catch{
            showError(error: "Error while loading data")
        }
    }
    @IBAction func actionLogOut(_ sender: Any) {
        self.doAction(user: user, login: false)
        self.dismiss(animated: true, completion: nil)
    }
    
}
