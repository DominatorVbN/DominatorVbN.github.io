//
//  ViewController.swift
//  AmitSamantMachineTest
//
//  Created by Apple on 05/02/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import UIKit
import CoreData

class SignUpVC: BaseVC {

    @IBOutlet weak var nameField: UITextField!
    @IBOutlet weak var emailField: UITextField!
    @IBOutlet weak var phoneField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    @IBOutlet weak var profileImageView: UIImageView!
    @IBOutlet weak var imageSpacerView: UIView!
    @IBOutlet weak var passwordStrenghtView: UIStackView!
    @IBOutlet weak var passwordStrenghtIdicator: UIView!
    @IBOutlet weak var passwordStrenghtLabel: UILabel!
    
    
    var selectedImage: UIImage? = nil{
        didSet{
            profileImageView.image = selectedImage
            updateImageStack()
        }
    }
    
    enum Segues{
        static let toProfile = "toProfile"
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    @IBAction func actionPickImage(_ sender: Any) {
        let imagePicker = UIImagePickerController()
        imagePicker.delegate = self
        self.present(imagePicker, animated: true, completion: nil)
    }
    
    @IBAction func actionSignUp(_ sender: Any) {
        if validateFields(){
            
            guard let context = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.viewContext else {
                showError(error: "Something went wrong!")
                return
            }
            
            let request: NSFetchRequest<User> = User.fetchRequest()
            do {
                let result = try context.fetch(request)
                guard result.first(where: {$0.email == emailField.text}) == nil else {
                    showError(error: "Email already been used try logging in.")
                    return
                }
            }catch{
                showError(error: "Error while loading data")
            }
            
            let user = User(context: context)
            user.name = nameField.text
            user.email = emailField.text
            user.password = passwordField.text
            user.phone = phoneField.text
            if let data = selectedImage!.pngData(){
                user.profileImage = NSData(data: data)
            }
            do {
                try context.save()
                Persistence.emailId = user.email
                self.doAction(user: user, login: true)
                self.performSegue(withIdentifier: Segues.toProfile, sender: nil)
            }catch{
                showError(error: "Error while saving data")
            }
        }
    }
    
    func validateFields()->Bool{
        let name = nameField.text ?? ""
        let email = emailField.text ?? ""
        let phone = phoneField.text ?? ""
        let password = passwordField.text ?? ""
        
        guard !name.isEmpty else {
            showError(error: "Name is required!")
            return false
        }
        
        guard !name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            showError(error: "Invaild name")
            return false
        }
        
        guard !email.isEmpty else{
            showError(error: "Email is required!")
            return false
        }
        
        guard validateEmail(enteredEmail: email) else{
            showError(error: "Invalid email!")
            return false
        }
        
        guard !phone.isEmpty else {
            showError(error: "Phone is required!")
            return false
        }
        
        guard !password.isEmpty else{
            showError(error: "Password is required!")
            return false
        }
        
        guard !password.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else{
            showError(error: "Invalid Password")
            return false
        }
        
        guard password.count > 3 else{
            showError(error: "Password have be atleast of 3 characters")
            return false
        }
        
        guard !password.contains(" ") else{
            showError(error: "Password can not contains spaces!")
            return false
        }
        
        guard selectedImage != nil else {
            showError(error: "Profile image is required!")
            return false
        }
        
        return true
    }
    

    
    func updateImageStack(){
        imageSpacerView.isHidden = selectedImage == nil
        profileImageView.isHidden = selectedImage == nil
    }
    
    @IBAction func didChangedPassword(_ sender: UITextField) {
        let passwordLenght = sender.text?.count ?? 0
        switch passwordLenght {
        case 0:
            passwordStrenghtView.isHidden = true
        case 1...3:
            passwordStrenghtView.isHidden = false
            passwordStrenghtIdicator.backgroundColor = UIColor.red
            passwordStrenghtLabel.text = "weak"
        case 4...6:
            passwordStrenghtView.isHidden = false
            passwordStrenghtIdicator.backgroundColor = UIColor.yellow
            passwordStrenghtLabel.text = "moderate"
        case 5...Int.max:
            passwordStrenghtView.isHidden = false
            passwordStrenghtIdicator.backgroundColor = UIColor.green
            passwordStrenghtLabel.text = "strong"
        default: break
        }
    }
    

    
}

extension SignUpVC:UINavigationControllerDelegate, UIImagePickerControllerDelegate{
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        self.selectedImage = info[UIImagePickerController.InfoKey.originalImage] as? UIImage
        picker.dismiss(animated: true, completion: nil)
    }
}
