//
//  LoginVC.swift
//  AmitSamantMachineTest
//
//  Created by Apple on 05/02/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import UIKit
import CoreData

class LoginVC: BaseVC {

    @IBOutlet weak var emailField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    
    enum Segues{
        static let toProfile = "toProfile"
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func actionLogin(_ sender: Any) {
        if validate(){
            guard let context = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.viewContext else {
                showError(error: "Something went wrong!")
                return
            }
            
            let request: NSFetchRequest<User> = User.fetchRequest()
            do {
                let result = try context.fetch(request)
                guard let user = result.first(where: {$0.email == emailField.text}) else{
                    showError(error: "No record found")
                    return
                }
                Persistence.emailId = user.email
                self.doAction(user: user, login: true)
                performSegue(withIdentifier: Segues.toProfile, sender: nil)
            }catch{
                showError(error: "Error while loading data")
            }
            
        }
    }
    
    func validate()->Bool{
        let email = emailField.text ?? ""
        let password = passwordField.text ?? ""
        
        guard !email.isEmpty else{
            showError(error: "Email is required!")
            return false
        }
        
        guard validateEmail(enteredEmail: email) else{
            showError(error: "Invalid email!")
            return false
        }
        
        guard !password.isEmpty else{
            showError(error: "Password is required!")
            return false
        }
        
        guard !password.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else{
            showError(error: "Invalid Password")
            return false
        }
        
        guard password.count > 3 else{
            showError(error: "Password have be atleast of 3 characters")
            return false
        }
        
        guard !password.contains(" ") else{
            showError(error: "Password can not contains spaces!")
            return false
        }
        
        return true
    }
    
}
