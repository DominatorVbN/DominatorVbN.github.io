//
//  User+CoreDataProperties.swift
//  AmitSamantMachineTest
//
//  Created by Apple on 05/02/20.
//  Copyright © 2020 Apple. All rights reserved.
//
//

import Foundation
import CoreData


extension User {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<User> {
        return NSFetchRequest<User>(entityName: "User")
    }

    @NSManaged public var email: String?
    @NSManaged public var name: String?
    @NSManaged public var password: String?
    @NSManaged public var phone: String?
    @NSManaged public var profileImage: NSData?
    @NSManaged public var origin: Log?

}
