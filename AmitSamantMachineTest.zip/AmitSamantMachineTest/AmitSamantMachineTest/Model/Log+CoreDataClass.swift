//
//  Log+CoreDataClass.swift
//  AmitSamantMachineTest
//
//  Created by Apple on 05/02/20.
//  Copyright © 2020 Apple. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Log)
public class Log: NSManagedObject {

}
